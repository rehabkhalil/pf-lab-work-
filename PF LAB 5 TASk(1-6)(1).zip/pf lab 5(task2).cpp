#include<iostream>
using namespace std;
int main()
{
	int number;
	cout<<"Enter a number:";
	cin>>number;
	while(number>1){
		cout<<number<<endl;
		number--;
	}
	return 0;	
}